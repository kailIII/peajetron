dhtmlxConnector for PHP v.1.5

Online Documentation: http://www.dhtmlx.com/dhxdocs/doku.php?id=dhtmlxconnector:start

(c) Dinamenta, UAB